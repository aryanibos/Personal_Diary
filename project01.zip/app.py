from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient
from datetime import datetime

client = MongoClient('mongodb+srv://aryaisnaidi01:123@cluster0.bd5ho.mongodb.net/')
db = client.dbsparta

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/diary', methods=['GET'])
def show_diary(): 
    # Mengambil semua data dari koleksi MongoDB
    articles = list(db.diary.find({}, {'_id': False}))  # Mengambil semua tanpa id
    return jsonify({'articles': articles})

@app.route('/diary', methods=['POST'])
def save_diary():
    title_receive = request.form['title_give']
    content_receive = request.form['content_give']
    
    # untuk melihat file yang diupload
    file = request.files['file_give']
    extension = file.filename.split('.')[-1]
    
    # membuat nama file yang unik
    today = datetime.now()
    date_time = today.strftime("%Y-%m-%d-%H-%M-%S")
    filename = f'static/post-{date_time}.{extension}'
    file.save(filename)
    
    # Mengolah gambar profil
    profile_file = request.files['profile_give']
    profile_extension = profile_file.filename.split('.')[-1]
    profile_filename = f'static/profile-{date_time}.{profile_extension}'
    profile_file.save(profile_filename)
        
    # Membuat format data untuk disimpan
    article = {
        'file': filename,
        'profile': profile_filename,
        'title': title_receive,
        'content': content_receive
    }
    
    # Menyimpan data ke MongoDB
    db.diary.insert_one(article)
    
    return jsonify({'msg': 'POST request complete!'})

if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)
